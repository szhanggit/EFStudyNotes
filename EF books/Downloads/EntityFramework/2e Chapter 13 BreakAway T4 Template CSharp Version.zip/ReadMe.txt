Chapter 13 MOdified T4 Template
In chapter 13, you added a T4 template for the BreakAway model using Microsoft's POCO template.
I had you make two modifications to the template.

1) Remove the use of the PropertyVirtualModifier which was called in 4 places. This results in the virtual keyword not being added for the entity properties.

2) Add logic (in various places) to generated property setter validation for MaxLength. This is done for strings where there is a MaxLength value defined in the model.

8/20: Currently you will find the C# template only. I will create one for VB as soon as I can.

www.learnentityframework.com